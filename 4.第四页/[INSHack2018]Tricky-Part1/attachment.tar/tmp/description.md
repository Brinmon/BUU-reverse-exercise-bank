# Tricky-Part1

I found this cool software on the internet but it is asking me for a license key. I really need it but I really don't known how to proceed. It might be tricky!
