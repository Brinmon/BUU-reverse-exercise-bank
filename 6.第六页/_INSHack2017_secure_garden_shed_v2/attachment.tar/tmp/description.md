# Secure Garden Shed v2.0

The next day, Caasi Vomisa receives a fix from The SGS Company. Yet this time
he wants to make sure that everything is okay with the binary.
    
    + sgs-exec-release-p (ELF32, built on Kubuntu 16.10)

Caasi also found a file on the Internet which could help him with finding the 
issue.

    + SGS-ASM.txt

Help Caasi to find if something's wrong with the binary.
