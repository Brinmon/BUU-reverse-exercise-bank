<b>Note:</b> This is the continuation of Cryptor Part2, you have to validate the first and second part to understand this challenge.<br>
Are you smart enough to decrypt this file?<br>
<b>Note: </b>The format of this flag is <i>INSAtheflaghere</i>, "theflaghere" being something else of course ;)
