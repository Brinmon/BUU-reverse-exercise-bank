Oh no! All the files on our workstation have been encrypted! Thankfully, we
found the .dll file that was used, and a logfile:

```
...
TODO(remove_debugging) MAC Address: 08:00:27:07:3d:f6
TODO(remove_debugging) Hostname: FLAGSVR (7)
TODO(remove_debugging) CPUID: AMDisbetter!
...
```

Can you decrypt it?
