# White House InSecurity - Part 1

We got access to the White House's registration page which allows to recover nuclear bomb codes.

Will you be able to recover the nuclear codes for `Bill Clinton` ?

Please note that it's easy to get a nuclear code that looks like a flag for any username, but only `Bill Clinton`'s code will be valid (and you guessed it, the system won't let you get that one too easily).

The White House's server is available at `nc whitehouse.ctf.insecurity-insa.fr 18470`
