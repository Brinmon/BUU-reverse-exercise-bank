# Secure Garden Shed v1.0

This morning, Caasi Vomisa wanted to mow his garden yet when he tried to open 
its Secure Garden Shed the lock kept refusing access. 
Caasi noticed a little maintenance plug on it and extracted the following files:
    
 + `sgs-exec-release` (ELF32, built on Kubuntu 16.10)
 + `lock.sgsc`

Caasi knows that his physical key used to open the shed should contain a file 
named key.txt but he couldn't retrieve it, it seems that the content is 
corrupted.
