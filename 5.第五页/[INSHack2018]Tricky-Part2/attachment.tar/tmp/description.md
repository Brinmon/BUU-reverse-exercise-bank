Great job, it seems that you were quite successful for the first binary. This one seems a bit trickier. Watch out where you're going.

*It is advised to do Part1 before Part2*
