# Proprietary CCTV Software

Caasi installed some new cameras to protect his house against thieves... 
But he needs a software to manage these cameras. After searching for an hour 
on the Internet an open-source tool or a freeware he finally finds a tool
on an obscure website.

Unfortunately, he does not succeed in cracking it... Can you give him a hand ?

He only knows that this program was compiled using Python 3.5.2+

Good luck !

You'll probably need to run `pip3 install PyQt5` 
before running the script using `python3 cctv_manager_activator.pyc`
