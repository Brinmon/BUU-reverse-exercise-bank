[This](https://static.ctf.insecurity-insa.fr/e2ccb4917c2c8305d2fda31133b3d37af880e7fb.tar.gz) is what happens when you let a manager create challenges for INS'hAck.

If you don't have Microsoft Excel, this challenge also works in Google Sheets.

IMPORTANT: there are two valid inputs, only one of them is the flag. The input that will give you the flag is the one with the highest sum of the two.
