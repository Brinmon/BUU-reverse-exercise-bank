Someone left [a strange script and some files](https://static.ctf.insecurity-insa.fr/a893dacde4b3fd97d924430b583bc7b3968b1ce4.tar.gz) on a server.

Will you help me understand what it did to a server ?
