<b>Note:</b> This is the continuation of Cryptor Part1, you have to validate the first part to understand this challenge.<br>
Something tagged as debug cannot be dangerous. It can be unstable though. Don't be a coward, run it.<br>
<b>Note: </b>The format of this flag is <i>INSAtheflaghere</i>, "theflaghere" being something else of course ;)
