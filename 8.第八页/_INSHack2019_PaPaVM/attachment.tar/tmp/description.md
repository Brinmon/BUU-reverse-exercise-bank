Are you a psychopath ? I am.

** PLEASE READ UNTIL THE END **

NOTA: NO BRUTEFORCE. FLAG IS PRINTABLE. Flag only contains letters, numbers, symbols.

Binary is [here](https://static.ctf.insecurity-insa.fr/a38f37cb17a0699c30cb02f6b871fbd6a723a884.tar.gz).

This binary accepts more than one valid input, if you found one, please head over here: `ssh -p 2231 user@papavm.ctf.insecurity-insa.fr` (password: `user`) and enter your flag!

