# Crypt0r part 3

You did a very good job until now. To be sure no one is going to be trapped again, could you find a way to protect the whole company?

To do so, you can use the binary located on the website of part 2, our expert told us that is was safe to run.

Note: you need to solve part 2 before attempting this part
