You're part of a malware analysts group and someone asks you to investigate a
storage dump recovered along with a static library.

"You might need to team up with a computer forensics expert to perform this analysis...", he said.

You'll find all of the material [here](https://static.ctf.insecurity-insa.fr/4f44b0118806de17474dd221243d31cc9fbc9a7c.tar.gz).
