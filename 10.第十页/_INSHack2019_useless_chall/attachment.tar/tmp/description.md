One of my friend sent me this binary and asked me if it was secure enough to act as the auth page of his highly secure password manager.

** PLEASE READ UNTIL THE END **

[https://www.youtube.com/watch?v=wWtXb61zYgc](https://www.youtube.com/watch?v=wWtXb61zYgc)

The binary is [here.](https://static.ctf.insecurity-insa.fr/eede865dc67d119882467715e3fa7fe352eae921.tar.gz)

NOTA: The flag is of the form `INSA{...}` and contains letters, numbers and symbols. And way too many characters to be able to bruteforce it :)

This binary accepts more than one valid input, if you found one, please head over here: `ssh -p 2230 user@useless-chall.ctf.insecurity-insa.fr` (password: `user`) and enter your flag!
